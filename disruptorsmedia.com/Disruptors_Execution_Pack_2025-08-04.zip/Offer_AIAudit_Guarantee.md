# Offer — AI Audit with $1,000 Guarantee

**Promise:** In a 60-minute recorded session, we’ll identify multiple concrete ways AI can improve your business. If we can’t, we pay you **$1,000**.

## What Counts as an Improvement
- Website conversion fixes, SEO wins, automations (CRM, routing, reporting), content ops, call flows, pipeline hygiene, analytics.

## Eligibility
- Registered business with active site.
- Owner/decision-maker attends live.
- Pre-form completed 24h prior.
- One audit per company per 12 months.
- We may decline misfit/abusive categories.

## Exclusions
- No-show, incomplete prep, or bad-faith participation.
- We identify **improvements** with implementation paths; we do not guarantee revenue outcomes.

## Payment Logistics
- If we fail to show improvements: company check or Zelle within 1 business day.

## Prep Form (required fields)
- Business name, URL(s), CRM, inbound sources, top 3 bottlenecks, sales cycle summary, current tech stack, permission to record.

## Meeting Flow (60 min)
1) 10m – Intake review & objectives
2) 40m – Live screenshare: prioritized findings
3) 10m – Next steps & offer
- Same-day deliverables: recording + written plan with priorities, owners, timelines.
