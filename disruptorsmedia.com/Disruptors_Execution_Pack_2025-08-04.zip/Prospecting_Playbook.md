# Prospecting Playbook — Bad Website/SEO List

## Targets
Local SMBs (contractors, home services, restaurants, clinics) with weak mobile UX, slow site, or missing SEO.

## Workflow
1) Crawl SERPs and local listings for category+city.
2) Enrich: website tech (CMS), GMB presence, estimated traffic, contact info.
3) Score: Website (0–10), SEO (0–10), intent signals.
4) Outreach: email v1 (website-first) or v2 (SEO-first).
5) Track status in `Prospect_Scoring_List_Template.csv`.

## Cold Email v1 (website-first)
Subject: Your homepage is costing you demos  
Noticed mobile UX issues and slow load. We fix that and tie it to pipeline. Want a 60‑min AI Audit? If we can’t find wins, we pay $1,000.

## Cold Email v2 (SEO-first)
Subject: You’re invisible for [category]+[city]  
We’ll outline 3 fixes in 60 minutes. If no wins, we pay $1,000. Worth a look?
