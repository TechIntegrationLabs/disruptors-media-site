# Testimonial Pack

## Ask (email)
Subject: Quick favor?  
Could we capture a short testimonial (5–7 min video or 3–4 lines written) about working with Disruptors? I’ll send 5 prompts and we’ll handle editing. Thanks!

## Prompts (video)
1) What was happening before we started?
2) Why did you pick us?
3) What did we do?
4) What changed? (any numbers welcome)
5) Who would you recommend us to?

## Notes
- Always ask for permission to publish.
- Capture logo, name, role, city/state.
- Add to `Testimonial_Tracker.csv`.
