# KPI Definitions

- **Signed_Deals_Count**: New logos closed this week.
- **Signed_Deals_Revenue_$**: New MRR or first‑month revenue from new deals.
- **Pipeline_Amount_$**: Sum of open opportunities (next 30 days).
- **New_Leads**: Net new contacts with intent (booked, inbound calls, forms).
- **Meetings_Set**: Booked meetings (not yet attended).
- **Show_Rate_%**: Attended / Meetings_Set * 100.
- **Close_Rate_%**: Won deals / Attended * 100.
- **Primary_Source**: Dominant channel for the week (Billboard/Social/Email/Referral).
