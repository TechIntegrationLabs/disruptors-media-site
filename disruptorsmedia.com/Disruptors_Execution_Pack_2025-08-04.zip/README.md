# Disruptors Execution Pack — 2025-08-04

This bundle contains the plan, checklists, copy decks, and spreadsheets to execute immediately.

## Quick Start
1) Launch **billboard** creative (Shock & Awe) today.
2) Publish the **AI Audit ($1,000 Guarantee)** page and open calendar slots.
3) Start the **reactivation** sequence.
4) Post daily per the **2-week content calendar**.
5) Collect **3 testimonials** this week.
6) Track progress in the included CSVs (KPI, Billboard, Prospects, Testimonials, Content).

## Contents
- `Plan.md`
- `Offer_AIAudit_Guarantee.md`
- `Landing_Copy_AIAudit.md`
- `Reactivation_Campaign.md`
- `Billboard_Copy_Deck.md`
- `GHL_Ops_Checklist.md`
- `Testimonial_Pack.md`
- `Prospecting_Playbook.md`
- `KPI_Definitions.md`
- `Social_Scripts_Templates.md`
- `Disruptors_Weekly_KPI_Tracker.csv`
- `Billboard_Campaign_Tracker.csv`
- `Prospect_Scoring_List_Template.csv`
- `Testimonial_Tracker.csv`
- `Content_Calendar_Aug4_Aug17.csv`
