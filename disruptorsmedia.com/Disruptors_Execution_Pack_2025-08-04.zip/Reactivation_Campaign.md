# Reactivation Campaign (10 Days)

## Segments
- Proposal Sent | No-Show | Warm | Old Cold

## Cadence
- **Emails (x5):** Days 1, 3, 5, 8, 10
- **SMS (x3):** Days 2, 6, 9
- **Ringless VM (x1):** Day 1

## Email Templates (short)
**E1 – Value:** Subject: “Built you a 60‑min AI Audit”  
We’ve packaged a one-hour AI Audit. If we can’t find wins for you, we pay $1,000. Want a slot this week?

**E2 – Proof:** Subject: “3 wins we found in under an hour”  
Last week we uncovered site conversion fixes, SEO gaps, and an automation that cut response time 70%. Want yours?

**E3 – Offer:** Subject: “Risk‑reversal: take $1,000 from us”  
Book the AI Audit—if we can’t show concrete improvements, we pay $1,000.

**E4 – Objections:** Subject: “No dev needed to start”  
Quick wins first. We’ll prioritize changes you can ship in days.

**E5 – Last call:** Subject: “Hold you a slot?”  
I can hold a time this week if you want in—reply yes/no.

## SMS (examples)
- “Opening AI Audit slots this week. If we can’t find wins, we pay $1,000. Want a link?”
- “Quick Q: want a 60‑min teardown on your site/SEO/flows? We’ll send you priorities.”
- “Last call—want me to hold a slot?”

## Ringless VM (script)
“Hey, it’s Will at Disruptors—opening a couple AI Audit slots. If we can’t find wins, we pay you $1,000. I’ll text a link.”
