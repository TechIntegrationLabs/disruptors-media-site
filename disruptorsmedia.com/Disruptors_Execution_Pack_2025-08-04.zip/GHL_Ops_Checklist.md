# Go High Level — Ops Checklist

- Buy new inbound number for Billboard.
- Enable Missed Call Text Back; voicemail to text.
- Create pipeline stages: Billboard, Social, Referral, Email.
- Round‑robin routing with backup failsafe.
- UTM capture & auto‑tag rules (source, medium, campaign).
- Calendar: “AI Audit” with buffers; confirmations & reminders (email+SMS).
- Automations:
  - Inbound – Billboard (tag, notify owner, task, SLA timer)
  - Reactivation 2025‑08 (emails/SMS/VM)
  - AI Audit – Show/No‑Show (reschedule, follow‑ups)
- Reporting dashboard: source performance, speed‑to‑lead, show/close rates.
