# Social Scripts & Templates

## Hooks (examples)
- AI will cut your ops time by 30%—here’s a 5‑minute playbook.
- Your website is losing you deals. 3 fixes you can do this week.
- $1,000 says we’ll find AI wins in your business. Want in?
- Bad billboard copy vs. good billboard copy (real examples).

## CTAs
- Comment “PLAYBOOK” for the checklist.
- DM “SITE” for a free homepage teardown.
- Book the AI Audit—spots this week.

## Formats
- 60–90s face‑to‑camera video; captions; first 3s = the hook.
- Repurpose to carousel with 5–7 slides: Hook → Problem → Value → Proof → CTA.
