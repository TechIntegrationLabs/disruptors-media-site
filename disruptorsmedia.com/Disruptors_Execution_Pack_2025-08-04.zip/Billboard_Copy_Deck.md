# Billboard Copy Deck + Checklist

## Lines (mix & match)
1) There are parts of your business you suck at. Let’s fix them.
2) Opportunities have never been bigger. If you’re not using AI, you’ll miss them.
3) $1,000 says we can show you how AI will improve your business. Challenge us.
4) Your pipeline problem isn’t luck. It’s systems. We build them.
5) If your website can’t sell, nothing else matters.
6) Stop being a secret. Get seen. Get chosen.
7) Your competitors are using AI. Are you?
8) Marketing that pays for itself or we’re not interested.
9) If it doesn’t move revenue, we don’t do it.
10) Book the AI Audit. Or take $1,000 from us.

## Implementation Checklist
- Unique GHL tracking number per variant
- QR code to /ai-audit with UTM: source=billboard, campaign=variant
- Missed call text back ON; call recording ON
- Pipeline: “Billboard – Inbound” stage + owner routing
- Daily lead review & response SLAs

## Legal Check (call script)
“We operate an on‑premise sign facing the freeway. Are static images with occasional copy swaps allowed? Any restrictions on scrolling text, animation, dwell time, brightness, or size? Which code sections apply and who can email written confirmation?”
