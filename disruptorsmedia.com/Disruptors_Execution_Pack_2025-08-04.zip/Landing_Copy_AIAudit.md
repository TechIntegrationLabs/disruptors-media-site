# Landing Copy — /ai-audit

## Hero
**$1,000 says we’ll find AI wins in your business.**  
If we can’t show you multiple concrete improvements in 60 minutes, we pay you $1,000.

[Book Your AI Audit] (Calendar widget)

## What You’ll Get
- A prioritized list of improvements across website, SEO, automations, CRM, and analytics.
- A recording of the session.
- Fast-start actions you can implement this week.

## Why It Works
We’ve productized what most teams spread across months: one focused session, clear fixes, immediate momentum.

## Proof / Testimonials
(Embed as you collect: video tiles + quotes.)

## Details & Fine Print
See the full terms of the guarantee below. (Anchor to terms section.)

## FAQ
- *What if we already use AI?* Great—most wins are stacking and orchestration.
- *Do you implement?* Yes. We can scope done-for-you or hybrid.
- *Is this for my industry?* If you have a website and leads, likely yes.
