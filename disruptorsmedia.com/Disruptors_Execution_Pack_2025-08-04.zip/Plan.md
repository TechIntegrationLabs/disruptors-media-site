# Execution Plan (Immediate)

## 0) Targets & Dashboard
- **Minimum:** $1,500 new MRR/week
- **Stretch:** $3,000 new MRR/week
- Update `Disruptors_Weekly_KPI_Tracker.csv` every Monday.

## 1) Billboard “Shock & Awe” (Today)
- Ship 2–3 variants with unique tracking numbers + QR/UTM.
- Route to **/ai-audit**; tag source = Billboard.
- See `Billboard_Copy_Deck.md` and `Billboard_Campaign_Tracker.csv`.

## 2) $1,000 AI Improvement Guarantee
- Publish **/ai-audit** with clear terms and booking widget.
- See `Offer_AIAudit_Guarantee.md` and `Landing_Copy_AIAudit.md`.

## 3) Reactivation Campaign (10-day)
- Email x5, SMS x3, 1 ringless VM to all warm/cold prior convos.
- See `Reactivation_Campaign.md`.

## 4) Social: 2-Week Sprint
- Follow `Content_Calendar_Aug4_Aug17.csv`.
- Use hooks/CTAs in `Social_Scripts_Templates.md`.
- Pin the guarantee post.

## 5) Testimonials (3 this week)
- Priority: Tyler Hill (video), Syke Pro (post-upsell), Jay (written).
- See `Testimonial_Pack.md` and track in `Testimonial_Tracker.csv`.

## 6) Prospecting (Nightly runs)
- Build list of local SMBs with weak site/SEO.
- Email v1/v2; score & track in `Prospect_Scoring_List_Template.csv`.
- See `Prospecting_Playbook.md`.

## 7) GHL / Ops
- New inbound number for billboards, missed-call text back ON.
- Round-robin routing, pipeline stages per source, UTM auto-tag.
- See `GHL_Ops_Checklist.md`.

## 8) Cadence/Discipline
- Weekly ops meeting (same slot), daily 60-min content block.
- Monday KPI review; update the tracker.
